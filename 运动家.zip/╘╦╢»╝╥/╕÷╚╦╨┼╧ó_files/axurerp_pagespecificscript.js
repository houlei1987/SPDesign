for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u24'] = 'top';document.getElementById('u13_img').tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('导航页.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u7'] = 'center';