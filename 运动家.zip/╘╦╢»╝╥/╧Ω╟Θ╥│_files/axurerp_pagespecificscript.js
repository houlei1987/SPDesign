for(var i = 0; i < 49; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('纠错.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'top';document.getElementById('u14_img').tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('路线.html');

}
});
gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u5'] = 'center';
u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('以地图形式查看.html');

}
});
gv_vAlignTable['u22'] = 'center';u47.tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('场地列表.html');

}
});
document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('导航页.html');

}
});

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	SetPanelVisibility('u40','','fade',500);

}
});
