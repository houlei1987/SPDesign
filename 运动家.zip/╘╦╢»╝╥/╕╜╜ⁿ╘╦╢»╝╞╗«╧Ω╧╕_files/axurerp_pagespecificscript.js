for(var i = 0; i < 62; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u41'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索页.html');

}
});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'center';
u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	SetPanelVisibility('u53','','none',500);

}
});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u42'] = 'top';u61.tabIndex = 0;

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('定位.html');

}
});
gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';