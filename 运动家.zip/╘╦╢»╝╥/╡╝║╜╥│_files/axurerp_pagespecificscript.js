for(var i = 0; i < 93; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u60'] = 'center';u89.tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索列表页.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'center';u92.tabIndex = 0;

u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('个人信息.html');

}
});
gv_vAlignTable['u83'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索框.html');

}
});
gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u5'] = 'center';document.getElementById('u12_img').tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('以地图形式查看.html');

}
});
gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u80'] = 'center';