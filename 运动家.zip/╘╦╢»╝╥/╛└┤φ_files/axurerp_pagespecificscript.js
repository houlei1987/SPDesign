for(var i = 0; i < 41; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	SetPanelVisibility('u32','','none',500);

}
});
gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'top';document.getElementById('u29_img').tabIndex = 0;

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('路线.html');

}
});
gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u21'] = 'center';document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('路线.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u14'] = 'center';
u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('以地图形式查看.html');

}
});
gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'top';document.getElementById('u39_img').tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('导航页.html');

}
});
gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u24'] = 'center';
u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u34'] = 'center';