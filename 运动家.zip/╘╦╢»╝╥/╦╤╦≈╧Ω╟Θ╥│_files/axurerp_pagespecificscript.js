for(var i = 0; i < 54; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索页.html');

}
});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u46'] = 'top';u53.tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('定位.html');

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u34'] = 'center';