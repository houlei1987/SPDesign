for(var i = 0; i < 139; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u89'] = 'top';
u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('主页.html');

}
});
gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u84'] = 'center';u138.tabIndex = 0;

u138.style.cursor = 'pointer';
$axure.eventManager.click('u138', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('定位.html');

}
});
gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u101'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索页.html');

}
});
gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u121'] = 'top';