for(var i = 0; i < 81; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u31'] = 'top';
u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('以地图形式查看.html');

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';document.getElementById('u78_img').tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('导航页.html');

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';u80.tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('详情页.html');

}
});
