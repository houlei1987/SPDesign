﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q)]),_(c,r,e,f,g,s,i,[_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y)]),_(c,z,e,f,g,A),_(c,B,e,f,g,C,i,[_(c,D,e,f,g,E)])])]);}; 
var b="rootNodes",c="pageName",d="主页",e="type",f="Wireframe",g="url",h="主页.html",i="children",j="以地图形式查看",k="以地图形式查看.html",l="导航页",m="导航页.html",n="个人中心",o="个人中心.html",p="个人信息",q="个人信息.html",r="搜索列表页",s="搜索列表页.html",t="详情页",u="详情页.html",v="场地列表",w="场地列表.html",x="纠错",y="纠错.html",z="搜索框",A="搜索框.html",B="路线",C="路线.html",D="路线详细",E="路线详细.html";
return _creator();
})();
