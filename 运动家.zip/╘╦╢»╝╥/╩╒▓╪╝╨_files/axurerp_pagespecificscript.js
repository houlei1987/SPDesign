for(var i = 0; i < 62; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u60'] = 'center';
u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'center';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('搜索页.html');

}
});
gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';u61.tabIndex = 0;

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('定位.html');

}
});
gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u56'] = 'center';
u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('附近运动计划.html');

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'center';